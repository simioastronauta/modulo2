"""
1 - Haz un programa en python que se conecte con
la base de datos "cinemanía" que hicimos en clase. El programa debe mostrar el nombre del actor y la
cantidad de películas en las que ha participado, ordenados de mayor a menor cantidad de películas.
"""

import mysql.connector

maria = mysql.connector.connect(
    host='localhost',
    user='manuel',
    password='1234',
    database='cinemania'
)
consulta = maria.cursor()

consulta.execute("SELECT nombre,primer_apellido,segundo_apellido,COUNT(peliculas_actores.id_actor) FROM actores_atrices JOIN peliculas_actores WHERE actores_atrices.id_actor = peliculas_actores.id_actor")
si = consulta.fetchall()
print(type(si))
for i in si:
    #consulta.execute("SELECT COUNT(peliculas_actores.id_actor)")
    print(i)