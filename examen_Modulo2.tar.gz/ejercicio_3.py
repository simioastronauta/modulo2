"""
3 - Crea una clase abstracta Empleado que tenga como atributos
 el nombre y el salario, y como método abstracto calcular_salario. Crea una
  subclase Programador que herede de Empleado y que tenga como atributo el número de
  líneas de código escritas por día, y como método calcular_salario que devuelva el salario base más un
  bonus en función del número de líneas de código. Crea otra subclase GestorProyectos que herede de Empleado
   y que tenga como atributo el número de proyectos gestionados por mes, y como método calcular_salario
que devuelva el salario base más un bonus en función del número de proyectos gestionados.
"""

from abc import ABC, abstractmethod
class Empleado(ABC):
    @abstractmethod
    def __init__(self,nombre,salario):
        self.nombre = nombre
        self.salario = salario

    def calcular_salario(self):
        pass

class Programador(Empleado):
    def __init__(self,nombre,salario,num_lineas_codg):
        super().__init__(nombre,salario)
        self.num_lineas_codg = num_lineas_codg

    def calcular_salario(self):
        bonus = 0

        while True:
            if self.num_lineas_codg >= 100:
                bonus += 10
                self.num_lineas_codg -= 100
            if self.num_lineas_codg < 100:
                break
        salario = self.salario + bonus
        print(f"El salario de {self.nombre} es {salario} euros")


class Gestor_proyectos(Empleado):
    def __init__(self,nombre,salario,num_gest):
        super().__init__(nombre,salario)
        self.num_gest = num_gest

    def calcular_salario(self):
        bonus = 0

        while True:
            if self.num_gest >= 10:
                bonus += 50
                self.num_gest -= 10
            if self.num_gest < 10:
                break
        salario = self.salario + bonus
        print(f"El salario de {self.nombre} es {salario} euros")

soldao1 = Programador("Carlos",2500,100)
soldao1.calcular_salario()

soldao2 = Programador("Reynildo", 3000, 856)
soldao2.calcular_salario()

gestor = Gestor_proyectos("Juan",4000, 23)
gestor.calcular_salario()