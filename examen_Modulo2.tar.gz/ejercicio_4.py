"""
2 - Usa esta dirección como referencia:
https://www.aemet.es/
Elige el municipio que quieras y haz un programa en python que, mediante
"scraping", muestre:

- Temperatura máxima
- Temperatura mínima
- Municipio

Los datos se tienen que mostrar en una ventana hecha en Tkinter.
"""

import requests
from bs4 import BeautifulSoup
import tkinter as tk

url_tiempo = "https://www.aemet.es/es/eltiempo/prediccion/municipios/malpica-de-bergantinos-id15043"
respuesta = requests.get(url_tiempo)
soponcio = BeautifulSoup(respuesta.text, 'html.parser')

temp_min = soponcio.find("span", class_="texto_azul").text
temp_max = soponcio.find("span", class_="texto_rojo").text
municipio = soponcio.find("h2",class_="titulo").text
print(temp_min)
print(temp_max)
print(municipio)
ventana = tk.Tk()
maxima = tk.Label(ventana, text=f"Maxima: {temp_max}")
maxima.grid()
minima = tk.Label(ventana, text=f"Minima: {temp_min}")
minima.grid()
munisipio = tk.Label(ventana, text=f"Munisipio: {municipio}")
munisipio.grid()
ventana.mainloop()