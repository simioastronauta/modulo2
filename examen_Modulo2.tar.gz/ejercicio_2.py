"""
2 - Usando la tabla de Excel que hemos usado en varias ocasiones,
 usa "pandas" para listar los salarios agrupados por
 estudios y género y ordenar por fecha de nacimiento de más viejos a más jóvenes.
"""
import pandas as pd
calculo = pd.read_excel("personas2.xlsx")
salario_estudios = calculo.groupby(['ESTUDIOS'])['SALARIO ANUAL'].mean()
print(f"{round(salario_estudios)} euros")
salario_genero = calculo.groupby(['GÉNERO'])['SALARIO ANUAL'].mean()
print(f"{round(salario_genero)} euros")
ordenaos = calculo.sort_values(by="FECHA NACIMIENTO",ascending=True)
print(ordenaos)