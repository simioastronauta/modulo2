from setuptools import setup

setup(
    name='betih',
    version='1',
    packages=[''],
    url='',
    license='',
    author='Simioastronauta',
    author_email='',
    description='',
    install_requires=open("requirements.txt").readlines()
)
